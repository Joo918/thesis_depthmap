def randomScheduler():
    