var url = "url req"

function logValue(thevalue){
    console.log("logging: " + thevalue);
  }

  module.exports.logValue = logValue;