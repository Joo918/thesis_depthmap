const http = require('http');
const fs = require('fs');
const url = require('url');

const hostname = '0.0.0.0';
const port = 8123;

var currentUser = "";

const server = http.createServer((req, res) => {
  
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');

  if (req.method == 'GET')
  {
    var urlObj = url.parse(req.url, true, false);
    if (urlObj.query['Hi'] != null)
    {
      res.write('welcome, ' + urlObj.query['Hi'] + '\n');
    }
    if (urlObj.query['startRecording'] != null)
    {
      //start recording contains the user name
      try {
        fs.accessSync('./' + urlObj.query['startRecording'] + '.txt', fs.constants.W_OK | fs.constants.R_OK);
        fs.unlinkSync('./' + urlObj.query['startRecording'] + '.txt');
      } catch (e) {

      }

      currentUser = urlObj.query['startRecording'];
      fs.appendFileSync('./' + urlObj.query['startRecording'] + '.txt', urlObj.query['startRecording'], 'utf8');

      console.log("starting recording");
    }
    if (urlObj.query['userResponse'] != null)
    {
      fs.appendFileSync('./' + currentUser + '.txt', ',' + urlObj.query['userResponse'], 'utf8');
    }

    if (urlObj.query['endRecording'] != null)
    {
      fs.appendFileSync('./' + currentUser + '.txt', 'end-of-response', 'utf8');
      currentUser = "";
      console.log("ending recording");
    }
  }
  else
  {
    console.log("NO SUPPORT FOR POST REQUESTS");
  }

  //console.log(req.headers);
  //console.log(req.method);

  res.write("testy test\n");

  res.end('Hello World');
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});